Google dino jumping game.

Jum key is KEYUP arrow.

My sons high score is 50 points :)

GAME resources

<a href='https://www.freepik.com/vectors/frame'>Frame vector created by valadzionak_volha - www.freepik.com</a>

<a href='https://pngtree.com/so/Blue'>Blue png from pngtree.com/</a>

<a href='https://www.freepik.com/vectors/tree'>Tree vector created by freepik - www.freepik.com</a>

<a href='https://www.freepik.com/vectors/background'>Background vector created by brgfx - www.freepik.com</a>